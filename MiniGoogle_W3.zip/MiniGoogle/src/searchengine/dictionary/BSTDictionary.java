package searchengine.dictionary;

public class BSTDictionary implements DictionaryInterface {

	@Override
	public String[] getKeys() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getValue(String key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(String key, Object value) {
		// TODO Auto-generated method stub

	}

	@Override
	public void remove(String key) {
		// TODO Auto-generated method stub

	}

}
